(function () {
  'use strict';

  var DEFAULTS = [
    { name: 'Gmail', url: 'https://mail.google.com' },
    { name: 'YouTube', url: 'https://www.youtube.com' },
    { name: 'GitHub', url: 'https://github.com' },
    { name: 'Claude', url: 'https://claude.ai' },
    { name: 'Drive', url: 'https://drive.google.com' }
  ];

  var shortcuts = [];
  var editIndex = -1;
  var rendered = false;

  var $ = function (id) { return document.getElementById(id); };
  var grid = $('grid'), dlg = $('dlg');

  /* ---------- Clock ---------- */
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function tick() {
    var d = new Date(), h = d.getHours();
    $('time').textContent = pad(h) + ':' + pad(d.getMinutes());
    $('date').textContent = d.toLocaleDateString(undefined,
      { weekday: 'long', day: 'numeric', month: 'long' });
    $('greeting').textContent =
      h < 12 ? 'Good morning \u2600\uFE0F' : h < 17 ? 'Good afternoon \uD83C\uDF24\uFE0F' : 'Good evening \uD83C\uDF19';
  }
  tick();
  setInterval(tick, 15000);

  /* ---------- Shortcuts ---------- */
  function normalizeUrl(u) {
    u = u.trim();
    return /^https?:\/\//i.test(u) ? u : 'https://' + u;
  }
  function hostOf(u) {
    try { return new URL(u).hostname; } catch (e) { return ''; }
  }
  function save() { chrome.storage.local.set({ shortcuts: shortcuts }); }

  function render() {
    grid.textContent = '';
    shortcuts.forEach(function (s, i) {
      var a = document.createElement('a');
      a.className = 'tile' + (rendered ? '' : ' enter');
      a.style.setProperty('--i', i);
      a.href = s.url;

      var ico = document.createElement('div');
      ico.className = 'ico';
      ico.textContent = (s.name[0] || '?').toUpperCase();
      var host = hostOf(s.url);
      if (host) {
        var img = new Image();
        img.alt = '';
        img.onload = function () { ico.textContent = ''; ico.appendChild(img); };
        img.src = 'https://www.google.com/s2/favicons?sz=64&domain=' + host;
      }

      var label = document.createElement('div');
      label.className = 'label';
      label.textContent = s.name;

      var tools = document.createElement('div');
      tools.className = 'tools';
      var ed = document.createElement('button');
      ed.type = 'button'; ed.title = 'Edit'; ed.textContent = '\u270E';
      ed.addEventListener('click', function (e) {
        e.preventDefault(); e.stopPropagation(); openDialog(i);
      });
      var del = document.createElement('button');
      del.type = 'button'; del.className = 'del'; del.title = 'Remove'; del.textContent = '\u00D7';
      del.addEventListener('click', function (e) {
        e.preventDefault(); e.stopPropagation();
        shortcuts.splice(i, 1); save(); render();
      });
      tools.appendChild(ed); tools.appendChild(del);

      a.appendChild(ico); a.appendChild(label); a.appendChild(tools);
      grid.appendChild(a);
    });

    var add = document.createElement('button');
    add.type = 'button';
    add.className = 'tile add';
    add.innerHTML = '<div class="ico">+</div><div class="label">Add shortcut</div>';
    add.addEventListener('click', function () { openDialog(-1); });
    grid.appendChild(add);
    rendered = true;
  }

  function openDialog(i) {
    editIndex = i;
    $('dlgTitle').textContent = i < 0 ? 'Add shortcut' : 'Edit shortcut';
    $('fName').value = i < 0 ? '' : shortcuts[i].name;
    $('fUrl').value = i < 0 ? '' : shortcuts[i].url;
    dlg.showModal();
    $('fName').focus();
  }
  $('cancel').addEventListener('click', function () { dlg.close(); });
  $('dlgForm').addEventListener('submit', function () {
    var item = { name: $('fName').value.trim(), url: normalizeUrl($('fUrl').value) };
    if (!item.name || !$('fUrl').value.trim()) return;
    if (editIndex < 0) shortcuts.push(item); else shortcuts[editIndex] = item;
    save(); render();
  });

  /* ---------- Notes ---------- */
  var noteTimer;
  $('note').addEventListener('input', function () {
    clearTimeout(noteTimer);
    noteTimer = setTimeout(function () {
      chrome.storage.local.set({ note: $('note').value });
    }, 300);
  });

  /* ---------- Load ---------- */
  chrome.storage.local.get(['shortcuts', 'note'], function (data) {
    shortcuts = Array.isArray(data.shortcuts) ? data.shortcuts : DEFAULTS.slice();
    if (!Array.isArray(data.shortcuts)) save();
    $('note').value = data.note || '';
    render();
  });
})();
