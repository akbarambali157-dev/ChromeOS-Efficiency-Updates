(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var host = '', skip = [];
  function say(m) { $('pStatus').textContent = m || ''; }
  function sync() { chrome.runtime.sendMessage({ type: 'darkSync' }); }

  chrome.storage.local.get(['darkMode', 'darkSkip'], function (d) {
    $('gDark').checked = !(d.darkMode && d.darkMode.on === false);
    skip = Array.isArray(d.darkSkip) ? d.darkSkip : [];
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      var u = tabs[0] && tabs[0].url || '';
      try { var x = new URL(u); if (/^https?:$/.test(x.protocol)) host = x.hostname; } catch (e) {}
      if (host) {
        $('siteTxt').textContent = 'Dark mode on ' + host;
        $('sDark').checked = skip.indexOf(host) < 0;
      } else {
        $('siteTxt').textContent = 'This site';
        $('siteSub').textContent = 'Open a website to change its setting';
        $('sDark').disabled = true;
      }
    });
  });

  $('gDark').addEventListener('change', function () {
    chrome.storage.local.set({ darkMode: { on: $('gDark').checked } }, sync);
  });
  $('sDark').addEventListener('change', function () {
    if (!host) return;
    var i = skip.indexOf(host);
    if ($('sDark').checked) { if (i >= 0) skip.splice(i, 1); }
    else if (i < 0) skip.push(host);
    chrome.storage.local.set({ darkSkip: skip }, sync);
  });

  function plural(n, w) { return n + ' ' + w + (n === 1 ? '' : 's'); }
  $('pDupes').addEventListener('click', function () {
    closeDupes().then(function (n) { say(n ? 'Closed ' + plural(n, 'duplicate tab') + '.' : 'No duplicate tabs.'); });
  });
  $('pMem').addEventListener('click', function () {
    freeMemory().then(function (n) { say(n ? 'Suspended ' + plural(n, 'tab') + '.' : 'Nothing to suspend.'); });
  });
  $('pOpen').addEventListener('click', function () {
    chrome.tabs.create({ url: chrome.runtime.getURL('memory.html') });
    window.close();
  });
})();
