(function (g) {
  'use strict';
  function key(t) {
    var u = (t.url || t.pendingUrl || '').split('#')[0];
    if (!u || u.indexOf('chrome://newtab') === 0 || u.indexOf('chrome-extension://') === 0) return '';
    return u;
  }
  g.closeDupes = function () {
    return chrome.tabs.query({ currentWindow: true }).then(function (tabs) {
      tabs.sort(function (a, b) {
        return ((b.active ? 2 : 0) + (b.pinned ? 1 : 0)) - ((a.active ? 2 : 0) + (a.pinned ? 1 : 0));
      });
      var seen = {}, drop = [];
      tabs.forEach(function (t) {
        var k = key(t);
        if (!k) return;
        if (seen[k] && !t.active && !t.pinned) drop.push(t.id); else seen[k] = true;
      });
      return drop.length ? chrome.tabs.remove(drop).then(function () { return drop.length; }) : 0;
    });
  };
  g.freeMemory = function () {
    return chrome.tabs.query({ active: false, audible: false, pinned: false, discarded: false }).then(function (tabs) {
      var jobs = tabs.map(function (t) {
        return chrome.tabs.discard(t.id).then(function () { return 1; }, function () { return 0; });
      });
      return Promise.all(jobs).then(function (r) { return r.reduce(function (a, b) { return a + b; }, 0); });
    });
  };
})(self);
