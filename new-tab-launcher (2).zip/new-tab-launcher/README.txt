My Launcher 1.9.0
Install: chrome://extensions -> Developer mode -> Load unpacked -> pick this folder.
After updating files, press the reload arrow on the extension.

Command bar: click the search box (or press /) and type "gh prs", "drive new sheet", a tab name, or a shortcut name.

Shortcuts (change at chrome://extensions/shortcuts):
  Alt+Shift+X  close duplicate tabs in this window
  Alt+Shift+F  suspend background tabs to free memory

Dark mode: on for all websites by default. Turn it off, or skip one site, from the toolbar button or Settings on the home page.

Assistant: open the Assistant tab (or the round button on the home page). Tap the mic or type. For general questions add your brewkeg key under Assistant settings.

Files: open the Files tab, choose a folder, press Scan. Then ask the assistant 'what files do I have'.
Email: ask the assistant 'check my email'. It reads your signed-in Gmail unread list (read only).
