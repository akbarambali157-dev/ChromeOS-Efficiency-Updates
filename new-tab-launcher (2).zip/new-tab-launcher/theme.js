(function () {
  'use strict';
  var de = document.documentElement;
  var MODES = ['none', 'aurora', 'mountains', 'stars', 'custom'];
  var custom = '';
  function ls(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }

  var t = ls('theme'); if (t) de.setAttribute('data-theme', t);
  var m = ls('motion'); if (m === 'off') de.setAttribute('data-motion', 'off');

  var MOUNTAINS =
    '<svg viewBox="0 0 1440 800" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg">' +
    '<defs><radialGradient id="wsg"><stop offset="0" style="stop-color:var(--accent);stop-opacity:.85"/>' +
    '<stop offset="1" style="stop-color:var(--accent);stop-opacity:0"/></radialGradient>' +
    '<linearGradient id="wsk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" style="stop-color:var(--bg)"/>' +
    '<stop offset="1" style="stop-color:var(--panel)"/></linearGradient></defs>' +
    '<rect width="1440" height="800" fill="url(#wsk)"/>' +
    '<circle class="sun" cx="1040" cy="380" r="200" fill="url(#wsg)"/>' +
    '<path class="m1" d="M-60 560 L100 500 L230 548 L380 470 L520 540 L680 460 L820 538 L980 480 L1130 552 L1280 490 L1500 556 L1500 800 L-60 800Z"/>' +
    '<path class="m2" d="M-60 640 L90 590 L240 640 L420 570 L580 650 L760 585 L930 655 L1100 600 L1260 660 L1500 610 L1500 800 L-60 800Z"/>' +
    '<path class="m3" d="M-60 720 L140 680 L330 730 L520 690 L720 745 L900 700 L1090 750 L1280 705 L1500 745 L1500 800 L-60 800Z"/>' +
    '</svg>';

  function setWall(mode) {
    var body = document.body;
    if (!body || body.hasAttribute('data-nowall')) return;
    var w = document.getElementById('wall');
    if (MODES.indexOf(mode) < 0) mode = 'aurora';
    if (mode === 'custom' && !custom) mode = 'aurora';
    if (mode === 'none') {
      if (w) w.remove();
      body.classList.remove('has-wall');
      return;
    }
    if (!w) {
      w = document.createElement('div');
      w.id = 'wall';
      body.insertBefore(w, body.firstChild);
    }
    w.className = mode;
    w.removeAttribute('style');
    w.textContent = '';
    body.classList.add('has-wall');
    if (mode === 'aurora') {
      w.innerHTML = '<i></i><i></i><i></i>';
    } else if (mode === 'mountains') {
      w.innerHTML = MOUNTAINS;
    } else if (mode === 'stars') {
      for (var i = 0; i < 55; i++) {
        var s = document.createElement('i');
        var sz = 1 + Math.random() * 2;
        s.style.cssText = 'left:' + (Math.random() * 100).toFixed(1) + '%;top:' + (Math.random() * 100).toFixed(1) +
          '%;width:' + sz.toFixed(1) + 'px;height:' + sz.toFixed(1) + 'px;animation-delay:-' + (Math.random() * 6).toFixed(1) +
          's;animation-duration:' + (3 + Math.random() * 4).toFixed(1) + 's';
        w.appendChild(s);
      }
      w.appendChild(document.createElement('b'));
    } else if (mode === 'custom') {
      w.style.backgroundImage = 'linear-gradient(rgba(10,16,22,.5),rgba(10,16,22,.5)),url("' + custom + '")';
    }
  }
  window.setWall = setWall;
  window.setCustomWall = function (url) { custom = url || ''; };

  document.addEventListener('DOMContentLoaded', function () {
    var mode = ls('wallMode');
    chrome.storage.local.get('wallpaper', function (d) {
      custom = d.wallpaper || '';
      if (!mode) {
        mode = custom ? 'custom' : 'aurora';
        try { localStorage.setItem('wallMode', mode); } catch (e) {}
      }
      setWall(mode);
    });
  });
})();
