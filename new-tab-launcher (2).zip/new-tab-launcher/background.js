importScripts('tools.js');
var DARK_IDS = ['dark-sites', 'dark-all', 'dark-main'];
function noop() {}

function hostOf(url) {
  try { var u = new URL(url); return /^https?:$/.test(u.protocol) ? u.hostname : ''; }
  catch (e) { return ''; }
}

/* ---------- Dark mode for websites (on by default) ---------- */
function getDark() {
  return chrome.storage.local.get(['darkMode', 'darkSkip']).then(function (d) {
    return {
      on: !(d.darkMode && d.darkMode.on === false),
      skip: (Array.isArray(d.darkSkip) ? d.darkSkip : []).filter(function (h) { return /^[a-z0-9.-]+$/i.test(h); })
    };
  });
}

function registerDark() {
  return getDark().then(function (c) {
    return chrome.scripting.getRegisteredContentScripts().then(function (all) {
      var ours = all.map(function (s) { return s.id; }).filter(function (id) { return DARK_IDS.indexOf(id) >= 0; });
      return ours.length ? chrome.scripting.unregisterContentScripts({ ids: ours }) : null;
    }).then(function () {
      if (!c.on) return;
      var excl = c.skip.map(function (h) { return '*://' + h + '/*'; });
      var base = { matches: ['http://*/*', 'https://*/*'], runAt: 'document_start' };
      var main = { id: 'dark-all', css: ['dark.css'], js: ['dark-detect.js'], matches: base.matches, runAt: base.runAt };
      var page = { id: 'dark-main', js: ['dark-main.js'], matches: base.matches, runAt: base.runAt, world: 'MAIN' };
      if (excl.length) { main.excludeMatches = excl; page.excludeMatches = excl; }
      return chrome.scripting.registerContentScripts([main]).then(function () {
        return chrome.scripting.registerContentScripts([page]).catch(noop);
      });
    });
  });
}

function syncTabs() {
  return Promise.all([getDark(), chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] })]).then(function (r) {
    var c = r[0];
    return Promise.all(r[1].map(function (t) {
      if (t.discarded) return null;
      var target = { tabId: t.id };
      var off = !c.on || c.skip.indexOf(hostOf(t.url)) >= 0;
      if (off) {
        return chrome.scripting.executeScript({
          target: target,
          func: function () {
            document.documentElement.setAttribute('data-dark-off', '1');
            document.documentElement.setAttribute('data-nodark', '1');
          }
        }).catch(noop);
      }
      return chrome.scripting.insertCSS({ target: target, files: ['dark.css'] })
        .then(function () { return chrome.scripting.executeScript({ target: target, files: ['dark-detect.js'] }); })
        .catch(noop);
    }));
  });
}

function applyDark() { return registerDark().then(syncTabs).catch(noop); }

chrome.runtime.onInstalled.addListener(function () { applyDark(); touchBorn(); });
chrome.runtime.onStartup.addListener(function () { applyDark(); touchBorn(); });

chrome.runtime.onMessage.addListener(function (msg) {
  if (msg && (msg.type === 'darkSync' || msg.type === 'reregister')) applyDark();
});

/* ---------- Shortcuts ---------- */
chrome.commands.onCommand.addListener(function (cmd) {
  if (cmd === 'close-dupes') closeDupes();
  else if (cmd === 'free-memory') freeMemory();
});

/* ---------- Tab age tracking (for the Memory page) ---------- */
function touchBorn() {
  return Promise.all([chrome.tabs.query({}), chrome.storage.session.get('born')]).then(function (r) {
    var b = r[1].born || {}, n = {}, now = Date.now();
    r[0].forEach(function (t) { n[t.id] = b[t.id] || now; });
    return chrome.storage.session.set({ born: n });
  }).catch(noop);
}
chrome.tabs.onCreated.addListener(function (t) {
  chrome.storage.session.get('born').then(function (r) {
    var b = r.born || {};
    b[t.id] = Date.now();
    return chrome.storage.session.set({ born: b });
  }).catch(noop);
});
chrome.tabs.onRemoved.addListener(function (id) {
  chrome.storage.session.get(['born', 'seen']).then(function (r) {
    var b = r.born || {}, s = r.seen || {};
    delete b[id]; delete s[id];
    return chrome.storage.session.set({ born: b, seen: s });
  }).catch(noop);
});

/* ---------- Auto-suspend idle tabs ---------- */
var CHECK = 'autosuspend-check';
chrome.alarms.get(CHECK).then(function (a) {
  if (!a) chrome.alarms.create(CHECK, { periodInMinutes: 1 });
});
chrome.alarms.onAlarm.addListener(function (a) {
  if (a.name === CHECK) { touchBorn(); sweep(); }
});

function neverSuspend(url) {
  try {
    var u = new URL(url);
    if (!/^https?:$/.test(u.protocol)) return true;
    var h = u.hostname;
    return /(^|\.)github\.dev$/.test(h) || /(^|\.)githubpreview\.dev$/.test(h) || h === 'localhost';
  } catch (e) { return true; }
}

function sweep() {
  return chrome.storage.local.get('autoSuspend').then(function (d) {
    var cfg = d.autoSuspend;
    var now = Date.now();
    return Promise.all([
      chrome.tabs.query({ active: false, audible: false, pinned: false, discarded: false }),
      chrome.storage.session.get('seen')
    ]).then(function (r) {
      var seen = r[1].seen || {}, next = {};
      var limit = cfg && cfg.on ? (cfg.minutes || 20) * 60000 : 0;
      r[0].forEach(function (t) {
        var ts = seen[t.id] || now;
        next[t.id] = ts;
        if (limit && !neverSuspend(t.url || '') && now - ts > limit) chrome.tabs.discard(t.id).catch(noop);
      });
      return chrome.storage.session.set({ seen: next });
    });
  }).catch(noop);
}
