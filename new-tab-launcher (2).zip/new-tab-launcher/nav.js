(function () {
  var items = [['newtab.html', 'Home'], ['github.html', 'GitHub'], ['drive.html', 'Drive'],
               ['brewkeg.html', 'Brewkeg'], ['sessions.html', 'Sessions'], ['memory.html', 'Memory'], ['assistant.html', 'Assistant'], ['files.html', 'Files']];
  var here = location.pathname.split('/').pop();
  var nav = document.querySelector('nav.nav');
  if (!nav || nav.children.length) return;
  items.forEach(function (it) {
    var a = document.createElement('a');
    a.href = it[0]; a.textContent = it[1];
    if (it[0] === here) a.className = 'on';
    nav.appendChild(a);
  });
})();
